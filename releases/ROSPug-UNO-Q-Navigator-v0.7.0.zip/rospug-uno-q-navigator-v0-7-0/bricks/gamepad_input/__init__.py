"""Gamepad input sidecar Brick."""
