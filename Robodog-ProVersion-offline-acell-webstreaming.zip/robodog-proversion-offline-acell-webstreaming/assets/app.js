const statusEl = document.getElementById("status");
const chatEl = document.getElementById("chat");
const actionsEl = document.getElementById("actions");

const composer = document.getElementById("composer");
const promptBox = document.getElementById("prompt");

const wifiSsidEl = document.getElementById("wifi_ssid");
const wifiPasswordEl = document.getElementById("wifi_password");
const wifiUrlEl = document.getElementById("wifi_url");
const wifiApEl = document.getElementById("wifi_ap");
const gamepadEl = document.getElementById("gamepad");

const vibrationValueEl = document.getElementById("vibration_value");
const vibrationStatusEl = document.getElementById("vibration_status");
const accelXEl = document.getElementById("accel_x");
const accelYEl = document.getElementById("accel_y");
const accelZEl = document.getElementById("accel_z");

const cameraViewEl = document.getElementById("camera_view");
const cameraStatusEl = document.getElementById("camera_status");

const detectionStatusEl = document.getElementById("detection_status");
const detectionImageEl = document.getElementById("detection_image");

function api(path) {
  return fetch(path).then(r => r.json());
}

function addChat(role, text) {
  const div = document.createElement("div");
  div.className = "msg " + role;
  div.innerHTML = `<b>${role}:</b> ${text}`;
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
}

async function refreshState() {
  try {
    const s = await api("/api/state");

    statusEl.textContent =
      `Mode: ${s.mode} | Last: ${s.last_command}`;

    wifiSsidEl.textContent = s.wifi_ssid || "DOGZILLA-UNOQ";
    wifiPasswordEl.textContent = s.wifi_password || "dogzilla123";
    wifiUrlEl.textContent = s.wifi_url || "http://10.42.0.1:7000";
    wifiApEl.textContent = s.wifi_ap || "unknown";

    gamepadEl.textContent = s.gamepad || "not connected";

    chatEl.innerHTML = "";

    for (const m of s.chat || []) {
      addChat(m.role, m.text);
    }

    const d = s.last_detection || {};
    if (d.ok) {
      detectionStatusEl.textContent =
        `Target: ${d.target} | Found: ${d.found} | Detections: ${d.count} | Time: ${d.processing_time_ms} ms`;

      if (d.image_base64) {
        detectionImageEl.src = "data:image/png;base64," + d.image_base64;
      }
    }

  } catch (e) {
    statusEl.textContent = "Backend not reachable: " + e.message;
  }
}

async function refreshCamera() {
  try {
    const c = await api("/api/camera");

    if (!c.ok || !c.frame_base64) {
      cameraStatusEl.textContent = "Camera error: " + (c.error || "no frame yet");
      cameraViewEl.removeAttribute("src");
      return;
    }

    cameraViewEl.src = "data:image/jpeg;base64," + c.frame_base64;
    cameraStatusEl.textContent = `Camera running | FPS: ${c.fps || 0}`;

  } catch (e) {
    cameraStatusEl.textContent = "Camera backend not reachable: " + e.message;
  }
}

async function refreshVibration() {
  try {
    const v = await api("/api/vibration");

    if (!v.ok) {
      vibrationStatusEl.textContent = "Error: " + (v.error || "unknown");
      vibrationValueEl.textContent = "0.000";
      accelXEl.textContent = "0.000";
      accelYEl.textContent = "0.000";
      accelZEl.textContent = "0.000";
      return;
    }

    const vib = Number(v.vibration || 0);
    const x = Number(v.x || 0);
    const y = Number(v.y || 0);
    const z = Number(v.z || 0);

    vibrationValueEl.textContent = vib.toFixed(3);
    accelXEl.textContent = x.toFixed(3);
    accelYEl.textContent = y.toFixed(3);
    accelZEl.textContent = z.toFixed(3);

    if (vib < 0.05) {
      vibrationStatusEl.textContent = "Stable / idle";
      vibrationStatusEl.className = "vibration-status stable";
    } else if (vib < 0.40) {
      vibrationStatusEl.textContent = "Normal robot movement";
      vibrationStatusEl.className = "vibration-status normal";
    } else if (vib < 1.20) {
      vibrationStatusEl.textContent = "High vibration";
      vibrationStatusEl.className = "vibration-status warning";
    } else {
      vibrationStatusEl.textContent = "Strong impact / possible fall";
      vibrationStatusEl.className = "vibration-status danger";
    }

  } catch (e) {
    vibrationStatusEl.textContent = "Backend not reachable: " + e.message;
  }
}

async function cmd(name) {
  addChat("owner", "Command: " + name);
  await api("/api/cmd/" + encodeURIComponent(name));
  await refreshState();
  await refreshVibration();
}

async function action(id) {
  addChat("owner", "Action " + id);
  await api("/api/action/" + id);
  await refreshState();
  await refreshVibration();
}

async function mode(name) {
  await api("/api/mode/" + encodeURIComponent(name));
  await refreshState();
}

async function gamepad(enabled) {
  const value = enabled ? "true" : "false";
  await api("/api/gamepad/" + value);
  await refreshState();
}

async function startAP() {
  addChat("owner", "Start WiFi Access Point");
  await api("/api/start_ap");
  await refreshState();
}

async function detectObject() {
  const target = document.getElementById("target").value;
  const language = document.getElementById("language").value;

  addChat("owner", `Find ${target} and respond in ${language}`);

  detectionStatusEl.textContent = "Running object detection...";

  const d = await api(
    "/api/detect/" +
    encodeURIComponent(target) +
    "/" +
    encodeURIComponent(language)
  );

  if (d.ok) {
    detectionStatusEl.textContent =
      `Target: ${d.target} | Found: ${d.found} | Detections: ${d.count} | Time: ${d.processing_time_ms} ms`;

    if (d.image_base64) {
      detectionImageEl.src = "data:image/png;base64," + d.image_base64;
    }
  } else {
    detectionStatusEl.textContent = "Detection error: " + (d.error || "unknown");
  }

  await refreshState();
  await refreshVibration();
}

composer.addEventListener("submit", async (e) => {
  e.preventDefault();

  const prompt = promptBox.value.trim();

  if (!prompt) return;

  promptBox.value = "";

  addChat("owner", prompt);

  await api("/api/chat/" + encodeURIComponent(prompt));

  await refreshState();
});

for (let i = 1; i <= 16; i++) {
  const b = document.createElement("button");
  b.textContent = "Action " + i;
  b.onclick = () => action(i);
  actionsEl.appendChild(b);
}

refreshState();
refreshVibration();
refreshCamera();

setInterval(refreshState, 2000);
setInterval(refreshVibration, 1000);
setInterval(refreshCamera, 300);