#include "Arduino_RouterBridge.h"
#include "Arduino_Modulino.h"

// --------------------------------------------------
// DOGZILLA UART
// --------------------------------------------------
HardwareSerial &DOG = Serial1;

// DOGZILLA protocol command addresses
#define CMD_BATTERY 0x01
#define CMD_MOVE_X  0x30
#define CMD_MOVE_Y  0x31
#define CMD_TURN    0x32
#define CMD_ACTION  0x3E

// --------------------------------------------------
// Modulino Movement
// --------------------------------------------------
ModulinoMovement movement;

float accel_x = 0.0;
float accel_y = 0.0;
float accel_z = 0.0;

float last_x = 0.0;
float last_y = 0.0;
float last_z = 0.0;

float vibration_value = 0.0;

// --------------------------------------------------
// DOGZILLA UART frame
// --------------------------------------------------
void sendFrame(uint8_t mode, uint8_t cmd, uint8_t value) {
  uint8_t pkt[9] = {
    0x55, 0x00, 0x09,
    mode,
    cmd,
    value,
    0x00,
    0x00,
    0xAA
  };

  pkt[6] = 255 - ((pkt[2] + pkt[3] + pkt[4] + pkt[5]) % 256);

  DOG.write(pkt, 9);
}

// --------------------------------------------------
// DOGZILLA movement
// --------------------------------------------------
void dog_forward() {
  sendFrame(0x01, CMD_MOVE_X, 180);
}

void dog_backward() {
  sendFrame(0x01, CMD_MOVE_X, 70);
}

void dog_left() {
  sendFrame(0x01, CMD_MOVE_Y, 180);
}

void dog_right() {
  sendFrame(0x01, CMD_MOVE_Y, 70);
}

void dog_turn_left() {
  sendFrame(0x01, CMD_TURN, 180);
}

void dog_turn_right() {
  sendFrame(0x01, CMD_TURN, 70);
}

void dog_stop() {
  sendFrame(0x01, CMD_MOVE_X, 128);
  sendFrame(0x01, CMD_MOVE_Y, 128);
  sendFrame(0x01, CMD_TURN,   128);
}

void dog_battery() {
  sendFrame(0x02, CMD_BATTERY, 0x01);
}

void dog_action(int id) {
  if (id < 1) id = 1;
  if (id > 255) id = 255;

  sendFrame(0x01, CMD_ACTION, (uint8_t)id);
}

// --------------------------------------------------
// Modulino Movement / vibration
// --------------------------------------------------
void update_movement() {
  movement.update();

  accel_x = movement.getX();
  accel_y = movement.getY();
  accel_z = movement.getZ();

  float dx = accel_x - last_x;
  float dy = accel_y - last_y;
  float dz = accel_z - last_z;

  vibration_value = sqrt(dx * dx + dy * dy + dz * dz);

  last_x = accel_x;
  last_y = accel_y;
  last_z = accel_z;
}

float get_accel_x() {
  update_movement();
  return accel_x;
}

float get_accel_y() {
  update_movement();
  return accel_y;
}

float get_accel_z() {
  update_movement();
  return accel_z;
}

float get_vibration() {
  update_movement();
  return vibration_value;
}

// Optional test action: stop robot if vibration is too high
void vibration_safety_check() {
  update_movement();

  if (vibration_value > 1.5) {
    dog_stop();
  }
}

// --------------------------------------------------
// Setup
// --------------------------------------------------
void setup() {
  DOG.begin(115200);

  Bridge.begin();
  Monitor.begin();

  // IMPORTANT: UNO Q Modulino bus uses Wire1
  Modulino.begin(Wire1);
  movement.begin();

  // DOGZILLA RouterBridge commands
  Bridge.provide("dog_forward", dog_forward);
  Bridge.provide("dog_backward", dog_backward);
  Bridge.provide("dog_left", dog_left);
  Bridge.provide("dog_right", dog_right);
  Bridge.provide("dog_turn_left", dog_turn_left);
  Bridge.provide("dog_turn_right", dog_turn_right);
  Bridge.provide("dog_stop", dog_stop);
  Bridge.provide("dog_battery", dog_battery);
  Bridge.provide("dog_action", dog_action);

  // Modulino vibration / acceleration RouterBridge commands
  Bridge.provide("get_accel_x", get_accel_x);
  Bridge.provide("get_accel_y", get_accel_y);
  Bridge.provide("get_accel_z", get_accel_z);
  Bridge.provide("get_vibration", get_vibration);

  delay(2000);

  dog_stop();

  Monitor.println("DOGZILLA + Modulino Movement ready");
}

// --------------------------------------------------
// Main loop
// --------------------------------------------------
void loop() {
  static unsigned long lastPrint = 0;

  update_movement();

  if (millis() - lastPrint > 1000) {
    lastPrint = millis();

    Monitor.println(
      "Acc (X,Y,Z) [G]: " +
      String(accel_x) + "," +
      String(accel_y) + "," +
      String(accel_z) +
      " | vibration: " +
      String(vibration_value)
    );
  }

  // Optional safety check
  // vibration_safety_check();

  delay(50);
}