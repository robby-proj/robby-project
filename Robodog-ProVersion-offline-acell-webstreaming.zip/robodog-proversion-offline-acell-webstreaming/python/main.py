import os
import time
import struct
import threading
import subprocess
import base64
import io
from urllib.parse import unquote

from PIL import Image

from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.object_detection import ObjectDetection

try:
    import cv2
except Exception:
    cv2 = None


ui = WebUI()
object_detection = ObjectDetection()

# ============================================================
# WiFi Access Point Settings
# ============================================================
AP_SSID = "DOGZILLA-UNOQ"
AP_PASSWORD = "dogzilla123"
AP_INTERFACE = "wlan0"
AP_URL = "http://10.42.0.1:7000"

# ============================================================
# Camera / Detection Settings
# ============================================================
CAMERA_INDEX = 0          # Change to 1 or 2 if your USB camera is /dev/video1 or /dev/video2
CAPTURE_DIR = "/tmp/robodog_captures"
CONFIDENCE = 0.45

os.makedirs(CAPTURE_DIR, exist_ok=True)

# ============================================================
# Live Camera Streaming
# ============================================================
CAMERA_FRAME_INTERVAL = 0.15  # ~6 FPS

CAMERA_STATE = {
    "ok": False,
    "running": False,
    "frame_base64": None,
    "timestamp": 0,
    "fps": 0,
    "error": None,
}

# ============================================================
# App State
# ============================================================
STATE = {
    "mode": "manual",
    "last_command": "none",
    "last_action": 0,

    "gamepad": "not connected",
    "gamepad_enabled": True,

    "wifi_ap": "not started",
    "wifi_ssid": AP_SSID,
    "wifi_password": AP_PASSWORD,
    "wifi_url": AP_URL,

    "target_object": "person",
    "language": "English",

    "vibration": {
        "ok": False,
        "x": 0,
        "y": 0,
        "z": 0,
        "vibration": 0,
    },

    "last_detection": {
        "ok": False,
        "target": None,
        "found": False,
        "count": 0,
        "processing_time_ms": None,
        "image_path": None,
        "image_base64": None,
        "detections": [],
    },

    "chat": [
        {"role": "robot", "text": "DOGZILLA AI Pro is ready."}
    ],
}

# ============================================================
# Gamepad Settings
# ============================================================
GAMEPAD_DEVICE = "/dev/input/js0"

JS_EVENT_FORMAT = "IhBB"
JS_EVENT_SIZE = struct.calcsize(JS_EVENT_FORMAT)

BTN_A = 0
BTN_B = 1
BTN_X = 2
BTN_Y = 3
BTN_L1 = 4
BTN_R1 = 5
BTN_SELECT = 8
BTN_START = 9

AXIS_LEFT_X = 0
AXIS_LEFT_Y = 1
AXIS_RIGHT_X = 3


# ============================================================
# General Helpers
# ============================================================
def robot_say(text):
    print("[ROBOT]", text, flush=True)
    STATE["chat"].append({"role": "robot", "text": text})
    STATE["chat"] = STATE["chat"][-40:]


def safe_float(value):
    try:
        return float(value)
    except Exception:
        return 0.0


def pil_to_png_base64(pil_image):
    buffer = io.BytesIO()
    pil_image.save(buffer, format="PNG")
    buffer.seek(0)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def pil_to_jpeg_base64(pil_image, quality=70):
    buffer = io.BytesIO()
    pil_image.save(buffer, format="JPEG", quality=quality)
    buffer.seek(0)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def normalize_label(label):
    return str(label).strip().lower().replace("_", " ")


def extract_detections(results):
    if not results:
        return []

    if isinstance(results, dict):
        if "detection" in results:
            return results.get("detection", [])
        if "detections" in results:
            return results.get("detections", [])

    return []


def detection_label(det):
    for key in ["label", "class", "name", "category"]:
        if key in det:
            return str(det[key])
    return "unknown"


def detection_score(det):
    for key in ["score", "confidence", "value"]:
        if key in det:
            try:
                return float(det[key])
            except Exception:
                return 0.0
    return 0.0


def detection_center_x(det, image_width):
    try:
        if all(k in det for k in ["x", "width"]):
            return float(det["x"]) + float(det["width"]) / 2.0

        if all(k in det for k in ["x1", "x2"]):
            return (float(det["x1"]) + float(det["x2"])) / 2.0

        if all(k in det for k in ["left", "right"]):
            return (float(det["left"]) + float(det["right"])) / 2.0

    except Exception:
        pass

    return image_width / 2.0


# ============================================================
# WiFi Access Point
# ============================================================
def start_wifi_access_point():
    print("Starting DOGZILLA WiFi Access Point...", flush=True)

    try:
        subprocess.run(
            [
                "/usr/bin/nmcli",
                "device",
                "wifi",
                "hotspot",
                "ifname",
                AP_INTERFACE,
                "ssid",
                AP_SSID,
                "password",
                AP_PASSWORD,
            ],
            check=True,
            capture_output=True,
            text=True,
        )

        STATE["wifi_ap"] = "active"
        STATE["wifi_ssid"] = AP_SSID
        STATE["wifi_password"] = AP_PASSWORD
        STATE["wifi_url"] = AP_URL

        robot_say(
            f"WiFi Access Point active. Connect to {AP_SSID} "
            f"with password {AP_PASSWORD}, then open {AP_URL}"
        )

    except Exception as e:
        STATE["wifi_ap"] = f"error: {e}"
        robot_say(f"WiFi AP failed: {e}")
        print(f"WiFi AP error: {e}", flush=True)


# ============================================================
# RouterBridge
# ============================================================
def bridge_call(name, *args):
    try:
        print(f"[BRIDGE] {name} {args}", flush=True)

        if args:
            return Bridge.call(name, *args)

        return Bridge.call(name)

    except Exception as e:
        print(f"[BRIDGE ERROR] {name}: {e}", flush=True)
        robot_say(f"Bridge error while running {name}: {e}")
        return {"error": str(e)}


# ============================================================
# Robot Commands
# ============================================================
def send_command(cmd):
    cmd = cmd.strip()
    STATE["last_command"] = cmd

    mapping = {
        "forward": "dog_forward",
        "backward": "dog_backward",
        "left": "dog_left",
        "right": "dog_right",
        "turn_left": "dog_turn_left",
        "turn_right": "dog_turn_right",
        "stop": "dog_stop",
        "battery": "dog_battery",
    }

    if cmd not in mapping:
        robot_say(f"Unknown command: {cmd}")
        return {"ok": False, "error": f"Unknown command: {cmd}"}

    result = bridge_call(mapping[cmd])

    if cmd == "battery":
        robot_say("Battery query sent.")
    else:
        robot_say(f"Command received: {cmd}")

    return {
        "ok": True,
        "cmd": cmd,
        "bridge": mapping[cmd],
        "result": result,
    }


def send_action(action_id):
    try:
        action_id = int(action_id)
    except Exception:
        return {"ok": False, "error": "Invalid action id"}

    if action_id < 1:
        action_id = 1
    if action_id > 255:
        action_id = 255

    STATE["last_action"] = action_id

    result = bridge_call("dog_action", action_id)
    robot_say(f"Running action {action_id}")

    return {
        "ok": True,
        "action": action_id,
        "result": result,
    }


# ============================================================
# Modulino Movement / Vibration
# ============================================================
def api_vibration():
    try:
        x = bridge_call("get_accel_x")
        y = bridge_call("get_accel_y")
        z = bridge_call("get_accel_z")
        vibration = bridge_call("get_vibration")

        data = {
            "ok": True,
            "x": safe_float(x),
            "y": safe_float(y),
            "z": safe_float(z),
            "vibration": safe_float(vibration),
        }

        STATE["vibration"] = data
        return data

    except Exception as e:
        data = {
            "ok": False,
            "error": str(e),
            "x": 0,
            "y": 0,
            "z": 0,
            "vibration": 0,
        }

        STATE["vibration"] = data
        return data


# ============================================================
# Camera Stream
# ============================================================
def camera_stream_loop():
    if cv2 is None:
        CAMERA_STATE["ok"] = False
        CAMERA_STATE["error"] = "OpenCV is not available"
        robot_say("Camera stream failed: OpenCV is not available.")
        return

    cap = None
    last_fps_time = time.time()
    frame_count = 0

    while True:
        try:
            if cap is None or not cap.isOpened():
                cap = cv2.VideoCapture(CAMERA_INDEX)

                if not cap.isOpened():
                    CAMERA_STATE["ok"] = False
                    CAMERA_STATE["running"] = False
                    CAMERA_STATE["error"] = f"Could not open camera index {CAMERA_INDEX}"
                    time.sleep(2)
                    continue

                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

                CAMERA_STATE["running"] = True
                CAMERA_STATE["error"] = None
                robot_say("USB camera stream started.")

            ok, frame = cap.read()

            if not ok or frame is None:
                CAMERA_STATE["ok"] = False
                CAMERA_STATE["error"] = "Camera frame read failed"
                time.sleep(0.5)
                continue

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(frame_rgb)

            CAMERA_STATE["frame_base64"] = pil_to_jpeg_base64(pil_image, quality=65)
            CAMERA_STATE["timestamp"] = time.time()
            CAMERA_STATE["ok"] = True
            CAMERA_STATE["error"] = None

            frame_count += 1
            now = time.time()

            if now - last_fps_time >= 1.0:
                CAMERA_STATE["fps"] = frame_count
                frame_count = 0
                last_fps_time = now

            time.sleep(CAMERA_FRAME_INTERVAL)

        except Exception as e:
            CAMERA_STATE["ok"] = False
            CAMERA_STATE["running"] = False
            CAMERA_STATE["error"] = str(e)
            print(f"[CAMERA ERROR] {e}", flush=True)

            try:
                if cap is not None:
                    cap.release()
            except Exception:
                pass

            cap = None
            time.sleep(2)


def api_camera():
    return {
        "ok": CAMERA_STATE["ok"],
        "running": CAMERA_STATE["running"],
        "frame_base64": CAMERA_STATE["frame_base64"],
        "timestamp": CAMERA_STATE["timestamp"],
        "fps": CAMERA_STATE["fps"],
        "error": CAMERA_STATE["error"],
    }


def get_latest_camera_frame_or_capture():
    """
    Prefer the latest camera stream frame. If not available, open the camera once.
    """
    if CAMERA_STATE.get("frame_base64"):
        raw = base64.b64decode(CAMERA_STATE["frame_base64"])
        return Image.open(io.BytesIO(raw)).convert("RGB")

    if cv2 is None:
        raise RuntimeError("OpenCV is not available in this App Lab environment.")

    cap = cv2.VideoCapture(CAMERA_INDEX)

    if not cap.isOpened():
        raise RuntimeError(f"Could not open camera index {CAMERA_INDEX}")

    for _ in range(5):
        cap.read()
        time.sleep(0.05)

    ok, frame = cap.read()
    cap.release()

    if not ok or frame is None:
        raise RuntimeError("Camera capture failed")

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    return Image.fromarray(frame_rgb)


# ============================================================
# Object Detection Brick
# ============================================================
def run_object_detection(target, language):
    target = normalize_label(target)
    language = unquote(language).strip()

    STATE["target_object"] = target
    STATE["language"] = language

    bridge_call("matrix_hello")
    robot_say(f"Looking for {target}. Please wait.")

    try:
        pil_image = get_latest_camera_frame_or_capture()

        timestamp = int(time.time())
        raw_path = os.path.join(CAPTURE_DIR, f"capture_{timestamp}.png")
        result_path = os.path.join(CAPTURE_DIR, f"capture_{timestamp}_detected.png")

        pil_image.save(raw_path)

        start_ms = time.time() * 1000
        results = object_detection.detect(pil_image, confidence=CONFIDENCE)
        elapsed_ms = time.time() * 1000 - start_ms

        detections = extract_detections(results)

        target_hits = []
        for det in detections:
            label = normalize_label(detection_label(det))
            if label == target:
                target_hits.append(det)

        found = len(target_hits) > 0

        annotated = object_detection.draw_bounding_boxes(pil_image, results)
        if annotated is None:
            annotated = pil_image

        annotated.save(result_path)

        image_b64 = pil_to_png_base64(annotated)

        simplified = []
        for det in detections:
            simplified.append({
                "label": detection_label(det),
                "score": detection_score(det),
                "raw": det,
            })

        STATE["last_detection"] = {
            "ok": True,
            "target": target,
            "found": found,
            "count": len(detections),
            "target_count": len(target_hits),
            "processing_time_ms": round(elapsed_ms, 2),
            "image_path": result_path,
            "image_base64": image_b64,
            "detections": simplified,
        }

        if found:
            img_w, _ = pil_image.size
            cx = detection_center_x(target_hits[0], img_w)

            if cx < img_w * 0.35:
                position = "left"
                motion = "turn_left"
            elif cx > img_w * 0.65:
                position = "right"
                motion = "turn_right"
            else:
                position = "center"
                motion = "forward"

            if STATE["mode"] == "autonomous":
                send_command(motion)

            if language.lower() == "spanish":
                robot_say(
                    f"Encontré {target}. Está hacia la zona {position}. "
                    f"Detecciones totales: {len(detections)}."
                )
            elif language.lower() == "portuguese":
                robot_say(
                    f"Encontrei {target}. Está na região {position}. "
                    f"Detecções totais: {len(detections)}."
                )
            elif language.lower() == "japanese":
                robot_say(
                    f"{target}を見つけました。位置は{position}です。"
                )
            elif language.lower() == "korean":
                robot_say(
                    f"{target}을 찾았습니다. 위치는 {position} 쪽입니다."
                )
            else:
                robot_say(
                    f"I found {target}. It is around the {position} area. "
                    f"Total detections: {len(detections)}."
                )

        else:
            send_command("stop")

            if language.lower() == "spanish":
                robot_say(f"No encontré {target}. Me detengo.")
            elif language.lower() == "portuguese":
                robot_say(f"Não encontrei {target}. Vou parar.")
            elif language.lower() == "japanese":
                robot_say(f"{target}は見つかりませんでした。停止します。")
            elif language.lower() == "korean":
                robot_say(f"{target}을 찾지 못했습니다. 정지합니다.")
            else:
                robot_say(f"I did not find {target}. Stopping.")

        return STATE["last_detection"]

    except Exception as e:
        STATE["last_detection"] = {
            "ok": False,
            "target": target,
            "found": False,
            "error": str(e),
            "image_base64": None,
            "detections": [],
        }

        robot_say(f"Object detection failed: {e}")

        return STATE["last_detection"]


# ============================================================
# USB Wireless Gamepad Loop
# ============================================================
def gamepad_loop():
    last_move = "stop"
    last_time = 0

    while True:
        if not STATE["gamepad_enabled"]:
            STATE["gamepad"] = "disabled"
            time.sleep(1)
            continue

        if not os.path.exists(GAMEPAD_DEVICE):
            STATE["gamepad"] = "not connected"
            time.sleep(1)
            continue

        STATE["gamepad"] = GAMEPAD_DEVICE

        try:
            with open(GAMEPAD_DEVICE, "rb") as js:
                robot_say("Wireless controller connected.")
                print(f"[GAMEPAD] connected: {GAMEPAD_DEVICE}", flush=True)

                while True:
                    evbuf = js.read(JS_EVENT_SIZE)

                    if not evbuf:
                        break

                    timestamp, value, event_type, number = struct.unpack(
                        JS_EVENT_FORMAT,
                        evbuf,
                    )

                    event_type_clean = event_type & ~0x80

                    if event_type_clean == 0x01 and value == 1:
                        if number == BTN_A:
                            send_action(1)
                        elif number == BTN_B:
                            send_command("stop")
                        elif number == BTN_X:
                            send_action(2)
                        elif number == BTN_Y:
                            send_action(3)
                        elif number == BTN_L1:
                            send_command("turn_left")
                        elif number == BTN_R1:
                            send_command("turn_right")
                        elif number == BTN_SELECT:
                            send_command("battery")
                        elif number == BTN_START:
                            send_action(255)

                    if event_type_clean == 0x02:
                        now = time.time()

                        if now - last_time < 0.25:
                            continue

                        cmd = None

                        if number == AXIS_LEFT_Y:
                            if value < -12000:
                                cmd = "forward"
                            elif value > 12000:
                                cmd = "backward"
                            else:
                                cmd = "stop"

                        elif number == AXIS_LEFT_X:
                            if value < -12000:
                                cmd = "left"
                            elif value > 12000:
                                cmd = "right"
                            else:
                                cmd = "stop"

                        elif number == AXIS_RIGHT_X:
                            if value < -12000:
                                cmd = "turn_left"
                            elif value > 12000:
                                cmd = "turn_right"
                            else:
                                cmd = "stop"

                        if cmd and cmd != last_move:
                            send_command(cmd)
                            last_move = cmd
                            last_time = now

        except Exception as e:
            STATE["gamepad"] = f"error: {e}"
            print(f"[GAMEPAD ERROR] {e}", flush=True)
            time.sleep(1)


# ============================================================
# WebUI API Functions
# ============================================================
def api_state():
    return STATE


def api_cmd(cmd):
    cmd = unquote(cmd).strip()
    return send_command(cmd)


def api_action(action_id):
    action_id = unquote(action_id).strip()
    return send_action(action_id)


def api_set_mode(mode):
    mode = unquote(mode).strip()

    if mode not in ["manual", "autonomous"]:
        mode = "manual"

    STATE["mode"] = mode

    if mode == "manual":
        send_command("stop")
        robot_say("Manual mode enabled.")
    else:
        robot_say("Autonomous mode enabled.")

    return {
        "ok": True,
        "mode": STATE["mode"],
    }


def api_toggle_gamepad(enabled):
    enabled = unquote(enabled).strip().lower()

    STATE["gamepad_enabled"] = enabled in ["1", "true", "yes", "on"]

    if STATE["gamepad_enabled"]:
        robot_say("Wireless controller enabled.")
    else:
        send_command("stop")
        robot_say("Wireless controller disabled.")

    return {
        "ok": True,
        "gamepad_enabled": STATE["gamepad_enabled"],
    }


def api_start_ap():
    start_wifi_access_point()

    return {
        "ok": True,
        "wifi_ap": STATE["wifi_ap"],
        "ssid": STATE["wifi_ssid"],
        "password": STATE["wifi_password"],
        "url": STATE["wifi_url"],
    }


def api_detect(target, language):
    target = unquote(target).strip()
    language = unquote(language).strip()

    return run_object_detection(target, language)


def api_chat(prompt):
    prompt = unquote(prompt).strip()

    if not prompt:
        return {
            "ok": False,
            "error": "empty prompt",
        }

    STATE["chat"].append({
        "role": "owner",
        "text": prompt,
    })

    if "hello" in prompt.lower() or "hola" in prompt.lower():
        bridge_call("matrix_hello")
        robot_say("Hello! I am ready to work.")
    else:
        robot_say(f"I received your message: {prompt}")

    return {
        "ok": True,
        "answer": STATE["chat"][-1]["text"],
    }


# ============================================================
# Register WebUI Routes
# ============================================================
ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/cmd/{cmd}", api_cmd)
ui.expose_api("GET", "/api/action/{action_id}", api_action)
ui.expose_api("GET", "/api/mode/{mode}", api_set_mode)
ui.expose_api("GET", "/api/gamepad/{enabled}", api_toggle_gamepad)
ui.expose_api("GET", "/api/start_ap", api_start_ap)
ui.expose_api("GET", "/api/detect/{target}/{language}", api_detect)
ui.expose_api("GET", "/api/chat/{prompt}", api_chat)
ui.expose_api("GET", "/api/vibration", api_vibration)
ui.expose_api("GET", "/api/camera", api_camera)

threading.Thread(target=gamepad_loop, daemon=True).start()
threading.Thread(target=camera_stream_loop, daemon=True).start()

print("Robodog AI Pro WebUI backend ready with camera stream.", flush=True)

App.run()