#include "Arduino_RouterBridge.h"
#include <Servo.h>

Servo gateServo;

const int SERVO_PIN = 9;
const int BUZZER_PIN = 8;


String currentState = "OFF";

void setup() {
  Bridge.begin();
  Monitor.begin();

  pinMode(BUZZER_PIN, OUTPUT);

  // Configure the pins as outputs
  pinMode(LED3_R, OUTPUT);
  pinMode(LED3_G, OUTPUT);
  pinMode(LED3_B, OUTPUT);
  // As they are active low, turn them OFF initially
  digitalWrite(LED3_R, HIGH);
  digitalWrite(LED3_G, HIGH);
  digitalWrite(LED3_B, HIGH);

  gateServo.attach(SERVO_PIN);
  gateServo.write(0);
  allOff();

  Bridge.provide_safe("set_beacon_state", set_beacon_state);

  Monitor.println("BLE Tracker MCU ready");
}

void allOff() {
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED3_R, HIGH);
  digitalWrite(LED3_G, HIGH);
  digitalWrite(LED3_B, HIGH);
}

void beepOnce() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(200);
  digitalWrite(BUZZER_PIN, LOW);
}

void set_beacon_state(String state, int rssi) {
  state.trim();
  allOff();

  if (state == "NEAR") {
    digitalWrite(LED3_R, HIGH);
    digitalWrite(LED3_G, LOW);
    digitalWrite(LED3_B, HIGH);
    gateServo.write(90);

    if (currentState != "NEAR") {
      beepOnce();
    }

    currentState = "NEAR";
  }

  else if (state == "MEDIUM") {
    digitalWrite(LED3_R, HIGH);
    digitalWrite(LED3_G, HIGH);
    digitalWrite(LED3_B, LOW);
    gateServo.write(45);
    currentState = "MEDIUM";
  }

  else if (state == "FAR") {
    digitalWrite(LED3_R, LOW);
    digitalWrite(LED3_G, HIGH);
    digitalWrite(LED3_B, HIGH);
    gateServo.write(0);
    currentState = "FAR";
  }

  else {
    digitalWrite(LED3_R, LOW);
    digitalWrite(LED3_G, LOW);
    digitalWrite(LED3_B, LOW);
    gateServo.write(0);
    currentState = "OFF";
  }

  Monitor.print("State: ");
  Monitor.print(state);
  Monitor.print(" RSSI: ");
  Monitor.println(rssi);
}


void loop() {
}
