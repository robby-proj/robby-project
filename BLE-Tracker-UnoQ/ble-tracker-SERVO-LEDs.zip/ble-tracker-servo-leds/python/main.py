from arduino.app_utils import App, Bridge
import json
import time
import urllib.request

API_URL = "http://192.168.1.234:5000/latest"

last_state = None
latest_data = {
    "status": "starting",
    "asset_name": "unknown",
    "mac": "unknown",
    "name": "unknown",
    "rssi": -100,
    "proximity": "unknown",
    "zone": "unknown",
    "timestamp_utc": ""
}


def read_ble_api():
    with urllib.request.urlopen(API_URL, timeout=2) as response:
        return json.loads(response.read().decode("utf-8"))


def state_from_proximity(proximity):
    proximity = str(proximity).lower()

    if proximity == "near":
        return "NEAR"
    elif proximity == "medium":
        return "MEDIUM"
    elif proximity == "far":
        return "FAR"
    else:
        return "OFF"


def send_to_mcu(state, rssi):
    global last_state

    if state != last_state:
        print(f"MCU update: {state}, RSSI={rssi}")
        Bridge.call("set_beacon_state", state, int(rssi))
        last_state = state
    else:
        print(f"No MCU change: {state}, RSSI={rssi}")


def loop():
    global latest_data

    try:
        data = read_ble_api()
        latest_data = data

        print("BLE:", data)

        if data.get("status") != "ok":
            send_to_mcu("OFF", -100)
            time.sleep(2)
            return

        proximity = data.get("proximity", "unknown")
        rssi = int(data.get("rssi", -100))

        state = state_from_proximity(proximity)
        send_to_mcu(state, rssi)

    except Exception as e:
        print("BLE API error:", e)
        latest_data = {
            "status": "error",
            "message": str(e),
            "rssi": -100,
            "proximity": "unknown"
        }
        send_to_mcu("OFF", -100)

    time.sleep(2)


App.run(user_loop=loop)
