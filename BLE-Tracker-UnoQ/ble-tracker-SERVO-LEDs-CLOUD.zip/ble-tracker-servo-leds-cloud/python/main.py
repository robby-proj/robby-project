from arduino.app_bricks.arduino_cloud import ArduinoCloud
from arduino.app_utils import App, Bridge

from collections import deque
import json
import time
import urllib.request


# =========================
# CONFIGURATION
# =========================

API_URL = "http://192.168.1.234:5000/latest"

RSSI_AVG_WINDOW = 25

NEAR_RSSI = -65
MEDIUM_RSSI = -80

POLL_SECONDS = 5


# =========================
# GLOBAL STATE
# =========================

arduino_cloud = ArduinoCloud()

last_state = None
rssi_window = deque(maxlen=RSSI_AVG_WINDOW)


# =========================
# ARDUINO CLOUD VARIABLES
# Match these names in Arduino Cloud
# =========================

arduino_cloud.register("ble_rssi_raw", value=0)
arduino_cloud.register("ble_rssi_avg", value=0)
arduino_cloud.register("ble_state", value="unknown")
arduino_cloud.register("ble_mac", value="unknown")
arduino_cloud.register("ble_asset", value="unknown")
arduino_cloud.register("ble_zone", value="unknown")


# =========================
# HELPERS
# =========================

def read_ble_api():
    with urllib.request.urlopen(API_URL, timeout=2) as response:
        return json.loads(response.read().decode("utf-8"))


def get_avg_rssi(new_rssi):
    rssi_window.append(int(new_rssi))
    return round(sum(rssi_window) / len(rssi_window))


def state_from_avg_rssi(avg_rssi):
    if avg_rssi >= NEAR_RSSI:
        return "NEAR"
    elif avg_rssi >= MEDIUM_RSSI:
        return "MEDIUM"
    else:
        return "FAR"


def send_to_mcu(state, rssi):
    global last_state

    if state != last_state:
        print(f"MCU update: {state}, avg RSSI={rssi}")
        Bridge.call("set_beacon_state", state, int(rssi))
        last_state = state
    else:
        print(f"No MCU change: {state}, avg RSSI={rssi}")


def update_cloud(data):
    arduino_cloud.ble_rssi_raw = int(data.get("rssi_raw", -100))
    arduino_cloud.ble_rssi_avg = int(data.get("rssi_avg", -100))
    arduino_cloud.ble_state = str(data.get("proximity", "unknown"))
    arduino_cloud.ble_mac = str(data.get("mac", "unknown"))
    arduino_cloud.ble_asset = str(data.get("asset_name", "unknown"))
    arduino_cloud.ble_zone = str(data.get("zone", "unknown"))

    print(
        "Cloud updated:",
        "raw=", arduino_cloud.ble_rssi_raw,
        "avg=", arduino_cloud.ble_rssi_avg,
        "state=", arduino_cloud.ble_state,
        "mac=", arduino_cloud.ble_mac
    )


# =========================
# MAIN LOOP
# =========================

def main_loop():
    while True:
        try:
            data = read_ble_api()
            print("BLE API:", data)

            if data.get("status") != "ok":
                send_to_mcu("OFF", -100)
                time.sleep(POLL_SECONDS)
                continue

            raw_rssi = int(data.get("rssi", -100))
            avg_rssi = get_avg_rssi(raw_rssi)
            state = state_from_avg_rssi(avg_rssi)

            data["rssi_raw"] = raw_rssi
            data["rssi_avg"] = avg_rssi
            data["proximity"] = state.lower()

            update_cloud(data)
            send_to_mcu(state, avg_rssi)

        except Exception as e:
            print("BLE / Cloud / MCU error:", e)
            send_to_mcu("OFF", -100)

        time.sleep(POLL_SECONDS)


# =========================
# START APP LAB CLOUD BRICK
# =========================

App.start_brick(arduino_cloud)
main_loop()