import os
import time
import json
import struct
import threading
import subprocess
from urllib.parse import unquote

from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI

ui = WebUI()

# ============================================================
# WiFi Access Point Settings
# ============================================================
AP_SSID = "DOGZILLA-UNOQ"
AP_PASSWORD = "dogzilla123"
AP_INTERFACE = "wlan0"
AP_URL = "http://10.42.0.1:7000"

# ============================================================
# App State
# ============================================================
STATE = {
    "mode": "manual",
    "last_command": "none",
    "last_action": 0,

    "gamepad": "not connected",
    "gamepad_enabled": True,

    "wifi_ap": "not started",
    "wifi_ssid": AP_SSID,
    "wifi_password": AP_PASSWORD,
    "wifi_url": AP_URL,

    "target_object": "person",
    "language": "English",

    "chat": [
        {"role": "robot", "text": "DOGZILLA AI Pro is ready."}
    ],
}

# ============================================================
# Gamepad Settings
# ============================================================
GAMEPAD_DEVICE = "/dev/input/js0"

# Linux joystick event format:
# time: uint32, value: int16, type: uint8, number: uint8
JS_EVENT_FORMAT = "IhBB"
JS_EVENT_SIZE = struct.calcsize(JS_EVENT_FORMAT)

# These may need tuning depending on the USB receiver mapping.
BTN_A = 0
BTN_B = 1
BTN_X = 2
BTN_Y = 3
BTN_L1 = 4
BTN_R1 = 5
BTN_SELECT = 8
BTN_START = 9

AXIS_LEFT_X = 0
AXIS_LEFT_Y = 1
AXIS_RIGHT_X = 3


# ============================================================
# Chat Helper
# ============================================================
def robot_say(text):
    print("[ROBOT]", text, flush=True)
    STATE["chat"].append({"role": "robot", "text": text})
    STATE["chat"] = STATE["chat"][-40:]


# ============================================================
# WiFi Access Point
# ============================================================
def start_wifi_access_point():
    print("Starting DOGZILLA WiFi Access Point...", flush=True)

    try:
        # This creates a local hotspot.
        # NetworkManager usually assigns 10.42.0.1 to wlan0.
        result = subprocess.run(
            [
                "nmcli",
                "device",
                "wifi",
                "hotspot",
                "ifname",
                AP_INTERFACE,
                "ssid",
                AP_SSID,
                "password",
                AP_PASSWORD,
            ],
            check=True,
            capture_output=True,
            text=True,
        )

        STATE["wifi_ap"] = "active"
        STATE["wifi_ssid"] = AP_SSID
        STATE["wifi_password"] = AP_PASSWORD
        STATE["wifi_url"] = AP_URL

        robot_say(
            f"WiFi Access Point active. Connect to {AP_SSID} "
            f"with password {AP_PASSWORD}, then open {AP_URL}"
        )

        print("WiFi AP active.", flush=True)
        print(f"SSID: {AP_SSID}", flush=True)
        print(f"Password: {AP_PASSWORD}", flush=True)
        print(f"URL: {AP_URL}", flush=True)

    except Exception as e:
        STATE["wifi_ap"] = f"error: {e}"
        robot_say(f"WiFi Access Point failed: {e}")
        print(f"WiFi AP error: {e}", flush=True)


# ============================================================
# RouterBridge Helper
# ============================================================
def bridge_call(name, *args):
    try:
        print(f"[BRIDGE] {name} {args}", flush=True)

        if args:
            return Bridge.call(name, *args)

        return Bridge.call(name)

    except Exception as e:
        print(f"[BRIDGE ERROR] {name}: {e}", flush=True)
        robot_say(f"Bridge error while running {name}: {e}")
        return {"error": str(e)}


# ============================================================
# Robot Command Helpers
# ============================================================
def send_command(cmd):
    cmd = cmd.strip()
    STATE["last_command"] = cmd

    mapping = {
        "forward": "dog_forward",
        "backward": "dog_backward",
        "left": "dog_left",
        "right": "dog_right",
        "turn_left": "dog_turn_left",
        "turn_right": "dog_turn_right",
        "stop": "dog_stop",
        "battery": "dog_battery",
    }

    if cmd not in mapping:
        robot_say(f"Unknown command: {cmd}")
        return {"ok": False, "error": f"Unknown command: {cmd}"}

    result = bridge_call(mapping[cmd])

    if cmd == "battery":
        robot_say("Battery query sent.")
    else:
        robot_say(f"Command received: {cmd}")

    return {
        "ok": True,
        "cmd": cmd,
        "bridge": mapping[cmd],
        "result": result,
    }


def send_action(action_id):
    try:
        action_id = int(action_id)
    except Exception:
        return {"ok": False, "error": "Invalid action id"}

    if action_id < 1:
        action_id = 1
    if action_id > 255:
        action_id = 255

    STATE["last_action"] = action_id

    result = bridge_call("dog_action", action_id)
    robot_say(f"Running action {action_id}")

    return {
        "ok": True,
        "action": action_id,
        "result": result,
    }


# ============================================================
# USB Wireless Gamepad Loop
# ============================================================
def gamepad_loop():
    last_move = "stop"
    last_time = 0

    while True:
        if not STATE["gamepad_enabled"]:
            STATE["gamepad"] = "disabled"
            time.sleep(1)
            continue

        if not os.path.exists(GAMEPAD_DEVICE):
            STATE["gamepad"] = "not connected"
            time.sleep(1)
            continue

        STATE["gamepad"] = GAMEPAD_DEVICE

        try:
            with open(GAMEPAD_DEVICE, "rb") as js:
                robot_say("Wireless controller connected.")
                print(f"[GAMEPAD] connected: {GAMEPAD_DEVICE}", flush=True)

                while True:
                    evbuf = js.read(JS_EVENT_SIZE)

                    if not evbuf:
                        break

                    timestamp, value, event_type, number = struct.unpack(
                        JS_EVENT_FORMAT,
                        evbuf,
                    )

                    # Remove init-event flag
                    event_type_clean = event_type & ~0x80

                    # Button event
                    if event_type_clean == 0x01 and value == 1:
                        if number == BTN_A:
                            send_action(1)
                        elif number == BTN_B:
                            send_command("stop")
                        elif number == BTN_X:
                            send_action(2)
                        elif number == BTN_Y:
                            send_action(3)
                        elif number == BTN_L1:
                            send_command("turn_left")
                        elif number == BTN_R1:
                            send_command("turn_right")
                        elif number == BTN_SELECT:
                            send_command("battery")
                        elif number == BTN_START:
                            send_action(255)

                    # Axis event
                    if event_type_clean == 0x02:
                        now = time.time()

                        # Rate limit movement commands
                        if now - last_time < 0.25:
                            continue

                        cmd = None

                        if number == AXIS_LEFT_Y:
                            if value < -12000:
                                cmd = "forward"
                            elif value > 12000:
                                cmd = "backward"
                            else:
                                cmd = "stop"

                        elif number == AXIS_LEFT_X:
                            if value < -12000:
                                cmd = "left"
                            elif value > 12000:
                                cmd = "right"
                            else:
                                cmd = "stop"

                        elif number == AXIS_RIGHT_X:
                            if value < -12000:
                                cmd = "turn_left"
                            elif value > 12000:
                                cmd = "turn_right"
                            else:
                                cmd = "stop"

                        if cmd and cmd != last_move:
                            send_command(cmd)
                            last_move = cmd
                            last_time = now

        except Exception as e:
            STATE["gamepad"] = f"error: {e}"
            print(f"[GAMEPAD ERROR] {e}", flush=True)
            time.sleep(1)


# ============================================================
# WebUI API Functions
# ============================================================
def api_state():
    return STATE


def api_cmd(cmd):
    cmd = unquote(cmd).strip()
    return send_command(cmd)


def api_action(action_id):
    action_id = unquote(action_id).strip()
    return send_action(action_id)


def api_set_mode(mode):
    mode = unquote(mode).strip()

    if mode not in ["manual", "autonomous"]:
        mode = "manual"

    STATE["mode"] = mode

    if mode == "manual":
        send_command("stop")
        robot_say("Manual mode enabled.")
    else:
        robot_say("Autonomous mode enabled.")

    return {
        "ok": True,
        "mode": STATE["mode"],
    }


def api_toggle_gamepad(enabled):
    enabled = unquote(enabled).strip().lower()

    STATE["gamepad_enabled"] = enabled in ["1", "true", "yes", "on"]

    if STATE["gamepad_enabled"]:
        robot_say("Wireless controller enabled.")
    else:
        send_command("stop")
        robot_say("Wireless controller disabled.")

    return {
        "ok": True,
        "gamepad_enabled": STATE["gamepad_enabled"],
    }


def api_start_ap():
    start_wifi_access_point()
    return {
        "ok": True,
        "wifi_ap": STATE["wifi_ap"],
        "ssid": STATE["wifi_ssid"],
        "password": STATE["wifi_password"],
        "url": STATE["wifi_url"],
    }


def api_detect(target, language):
    target = unquote(target).strip()
    language = unquote(language).strip()

    STATE["target_object"] = target
    STATE["language"] = language

    # Phase 1 placeholder.
    # Next phase connects:
    # USB camera -> YOLO COCO -> saved image -> SmolVLM 500M GGUF.
    robot_say(
        f"Object detection requested. Target: {target}. "
        f"Language: {language}. "
        "Camera, YOLO, and VLM will be connected in the next step."
    )

    return {
        "ok": True,
        "target": target,
        "language": language,
        "message": "Detection placeholder active",
    }


def api_chat(prompt):
    prompt = unquote(prompt).strip()

    if not prompt:
        return {
            "ok": False,
            "error": "empty prompt",
        }

    STATE["chat"].append({
        "role": "owner",
        "text": prompt,
    })

    robot_say(f"I received your message: {prompt}")

    return {
        "ok": True,
        "answer": STATE["chat"][-1]["text"],
    }


# ============================================================
# Register WebUI Routes
# ============================================================
ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/cmd/{cmd}", api_cmd)
ui.expose_api("GET", "/api/action/{action_id}", api_action)
ui.expose_api("GET", "/api/mode/{mode}", api_set_mode)
ui.expose_api("GET", "/api/gamepad/{enabled}", api_toggle_gamepad)
ui.expose_api("GET", "/api/start_ap", api_start_ap)
ui.expose_api("GET", "/api/detect/{target}/{language}", api_detect)
ui.expose_api("GET", "/api/chat/{prompt}", api_chat)

# Start background gamepad reader
threading.Thread(target=gamepad_loop, daemon=True).start()

# Start WiFi AP automatically when the app starts
start_wifi_access_point()

print("Robodog AI Pro WebUI backend ready.", flush=True)

App.run()