#include <Arduino.h>
#include <Arduino_RouterBridge.h>

HardwareSerial &DOG = Serial1;

// DOGZILLA protocol command addresses
#define CMD_BATTERY 0x01
#define CMD_MOVE_X  0x30
#define CMD_MOVE_Y  0x31
#define CMD_TURN    0x32
#define CMD_ACTION  0x3E

void sendFrame(uint8_t mode, uint8_t cmd, uint8_t value) {
  uint8_t pkt[9] = {
    0x55, 0x00, 0x09,
    mode,
    cmd,
    value,
    0x00,
    0x00,
    0xAA
  };

  pkt[6] = 255 - ((pkt[2] + pkt[3] + pkt[4] + pkt[5]) % 256);

  DOG.write(pkt, 9);
}

// -----------------------------
// Movement functions
// -----------------------------
void dog_forward() {
  sendFrame(0x01, CMD_MOVE_X, 180);
}

void dog_backward() {
  sendFrame(0x01, CMD_MOVE_X, 70);
}

void dog_left() {
  sendFrame(0x01, CMD_MOVE_Y, 180);
}

void dog_right() {
  sendFrame(0x01, CMD_MOVE_Y, 70);
}

void dog_turn_left() {
  sendFrame(0x01, CMD_TURN, 180);
}

void dog_turn_right() {
  sendFrame(0x01, CMD_TURN, 70);
}

void dog_stop() {
  sendFrame(0x01, CMD_MOVE_X, 128);
  sendFrame(0x01, CMD_MOVE_Y, 128);
  sendFrame(0x01, CMD_TURN,   128);
}

// -----------------------------
// Status and actions
// -----------------------------
void dog_battery() {
  sendFrame(0x02, CMD_BATTERY, 0x01);
}

void dog_action(int id) {
  if (id < 1) id = 1;
  if (id > 255) id = 255;

  sendFrame(0x01, CMD_ACTION, (uint8_t)id);
}

void setup() {
  DOG.begin(115200);

  Bridge.begin();

  Bridge.provide("dog_forward", dog_forward);
  Bridge.provide("dog_backward", dog_backward);
  Bridge.provide("dog_left", dog_left);
  Bridge.provide("dog_right", dog_right);
  Bridge.provide("dog_turn_left", dog_turn_left);
  Bridge.provide("dog_turn_right", dog_turn_right);
  Bridge.provide("dog_stop", dog_stop);
  Bridge.provide("dog_battery", dog_battery);
  Bridge.provide("dog_action", dog_action);

  delay(2000);
  dog_stop();
}

void loop() {
  // RouterBridge handles Linux → MCU calls.
  // DOGZILLA UART remains dedicated on Serial1.
}