const statusEl = document.getElementById("status");
const chatEl = document.getElementById("chat");
const actionsEl = document.getElementById("actions");

const composer = document.getElementById("composer");
const promptBox = document.getElementById("prompt");

const wifiSsidEl = document.getElementById("wifi_ssid");
const wifiPasswordEl = document.getElementById("wifi_password");
const wifiUrlEl = document.getElementById("wifi_url");
const wifiApEl = document.getElementById("wifi_ap");
const gamepadEl = document.getElementById("gamepad");

function api(path) {
  return fetch(path).then(r => r.json());
}

function addChat(role, text) {
  const div = document.createElement("div");
  div.className = "msg " + role;
  div.innerHTML = `<b>${role}:</b> ${text}`;
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
}

async function refreshState() {
  try {
    const s = await api("/api/state");

    statusEl.textContent =
      `Mode: ${s.mode} | Last: ${s.last_command}`;

    wifiSsidEl.textContent = s.wifi_ssid || "DOGZILLA-UNOQ";
    wifiPasswordEl.textContent = s.wifi_password || "dogzilla123";
    wifiUrlEl.textContent = s.wifi_url || "http://10.42.0.1:7000";
    wifiApEl.textContent = s.wifi_ap || "unknown";

    gamepadEl.textContent = s.gamepad || "not connected";

    chatEl.innerHTML = "";

    for (const m of s.chat || []) {
      addChat(m.role, m.text);
    }

  } catch (e) {
    statusEl.textContent = "Backend not reachable: " + e.message;
  }
}

async function cmd(name) {
  addChat("owner", "Command: " + name);
  await api("/api/cmd/" + encodeURIComponent(name));
  await refreshState();
}

async function action(id) {
  addChat("owner", "Action " + id);
  await api("/api/action/" + id);
  await refreshState();
}

async function mode(name) {
  await api("/api/mode/" + encodeURIComponent(name));
  await refreshState();
}

async function gamepad(enabled) {
  const value = enabled ? "true" : "false";
  await api("/api/gamepad/" + value);
  await refreshState();
}

async function startAP() {
  addChat("owner", "Start WiFi Access Point");
  await api("/api/start_ap");
  await refreshState();
}

async function detectObject() {
  const target = document.getElementById("target").value;
  const language = document.getElementById("language").value;

  addChat("owner", `Find ${target} and respond in ${language}`);

  await api(
    "/api/detect/" +
    encodeURIComponent(target) +
    "/" +
    encodeURIComponent(language)
  );

  await refreshState();
}

composer.addEventListener("submit", async (e) => {
  e.preventDefault();

  const prompt = promptBox.value.trim();

  if (!prompt) return;

  promptBox.value = "";

  addChat("owner", prompt);

  await api("/api/chat/" + encodeURIComponent(prompt));

  await refreshState();
});

for (let i = 1; i <= 16; i++) {
  const b = document.createElement("button");
  b.textContent = "Action " + i;
  b.onclick = () => action(i);
  actionsEl.appendChild(b);
}

refreshState();
setInterval(refreshState, 2000);